import { Footwear, Brand, Bill, User } from '../types';

const STORAGE_KEYS = {
  FOOTWEAR: 'footwear_stock',
  BRANDS: 'brands',
  BILLS: 'bills',
  USERS: 'users',
  CURRENT_USER: 'current_user',
};

export const storageService = {
  getFootwear(): Footwear[] {
    const data = localStorage.getItem(STORAGE_KEYS.FOOTWEAR);
    return data ? JSON.parse(data) : [];
  },

  saveFootwear(footwear: Footwear[]): void {
    localStorage.setItem(STORAGE_KEYS.FOOTWEAR, JSON.stringify(footwear));
  },

  addFootwear(footwear: Footwear): void {
    const items = this.getFootwear();
    items.push(footwear);
    this.saveFootwear(items);
  },

  updateFootwear(id: string, updates: Partial<Footwear>): void {
    const items = this.getFootwear();
    const index = items.findIndex(item => item.id === id);
    if (index !== -1) {
      items[index] = { ...items[index], ...updates, updatedAt: new Date().toISOString() };
      this.saveFootwear(items);
    }
  },

  deleteFootwear(id: string): void {
    const items = this.getFootwear();
    const filtered = items.filter(item => item.id !== id);
    this.saveFootwear(filtered);
  },

  getBrands(): Brand[] {
    const data = localStorage.getItem(STORAGE_KEYS.BRANDS);
    return data ? JSON.parse(data) : [];
  },

  saveBrands(brands: Brand[]): void {
    localStorage.setItem(STORAGE_KEYS.BRANDS, JSON.stringify(brands));
  },

  addBrand(brand: Brand): void {
    const brands = this.getBrands();
    brands.push(brand);
    this.saveBrands(brands);
  },

  updateBrand(id: string, name: string): void {
    const brands = this.getBrands();
    const index = brands.findIndex(b => b.id === id);
    if (index !== -1) {
      brands[index].name = name;
      this.saveBrands(brands);
    }
  },

  deleteBrand(id: string): void {
    const brands = this.getBrands();
    const filtered = brands.filter(b => b.id !== id);
    this.saveBrands(filtered);
  },

  getBills(): Bill[] {
    const data = localStorage.getItem(STORAGE_KEYS.BILLS);
    return data ? JSON.parse(data) : [];
  },

  saveBills(bills: Bill[]): void {
    localStorage.setItem(STORAGE_KEYS.BILLS, JSON.stringify(bills));
  },

  addBill(bill: Bill): void {
    const bills = this.getBills();
    bills.push(bill);
    this.saveBills(bills);
  },

  getUsers(): User[] {
    const data = localStorage.getItem(STORAGE_KEYS.USERS);
    return data ? JSON.parse(data) : [];
  },

  saveUsers(users: User[]): void {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  },

  getCurrentUser(): User | null {
    const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  },

  setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  },

  initializeDefaultData(): void {
    if (this.getUsers().length === 0) {
      this.saveUsers([
        {
          id: '1',
          username: 'admin',
          password: 'admin123',
          name: 'Administrator',
        },
      ]);
    }

    if (this.getBrands().length === 0) {
      const defaultBrands: Brand[] = [
        { id: '1', name: 'Nike', createdAt: new Date().toISOString() },
        { id: '2', name: 'Adidas', createdAt: new Date().toISOString() },
        { id: '3', name: 'Puma', createdAt: new Date().toISOString() },
        { id: '4', name: 'Reebok', createdAt: new Date().toISOString() },
        { id: '5', name: 'Bata', createdAt: new Date().toISOString() },
      ];
      this.saveBrands(defaultBrands);
    }

    if (this.getFootwear().length === 0) {
      const defaultFootwear: Footwear[] = [
        {
          id: '1',
          brandId: '1',
          brandName: 'Nike',
          category: 'Men',
          type: 'Sports',
          size: '9',
          color: 'Black',
          section: 'A',
          rack: '1',
          shelf: '2',
          costPrice: 2500,
          sellingPrice: 3500,
          quantity: 15,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: '2',
          brandId: '2',
          brandName: 'Adidas',
          category: 'Women',
          type: 'Casual',
          size: '7',
          color: 'White',
          section: 'B',
          rack: '2',
          shelf: '1',
          costPrice: 2000,
          sellingPrice: 2800,
          quantity: 8,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: '3',
          brandId: '3',
          brandName: 'Puma',
          category: 'Kids',
          type: 'Sports',
          size: '5',
          color: 'Blue',
          section: 'C',
          rack: '1',
          shelf: '3',
          costPrice: 1500,
          sellingPrice: 2200,
          quantity: 3,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ];
      this.saveFootwear(defaultFootwear);
    }
  },
};
