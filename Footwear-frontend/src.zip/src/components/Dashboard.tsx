import { useEffect, useState } from 'react';
import { storageService } from '../services/storage';
import { DashboardStats, Footwear } from '../types';
import { Package, Tag, AlertTriangle, DollarSign, FileText } from 'lucide-react';

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalStock: 0,
    totalBrands: 0,
    lowStockItems: 0,
    todaySales: 0,
    todayBills: 0,
  });
  const [lowStockItems, setLowStockItems] = useState<Footwear[]>([]);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = () => {
    const footwear = storageService.getFootwear();
    const brands = storageService.getBrands();
    const bills = storageService.getBills();

    const today = new Date().toISOString().split('T')[0];
    const todayBills = bills.filter(b => b.createdAt.startsWith(today));
    const todaySales = todayBills.reduce((sum, bill) => sum + bill.finalAmount, 0);

    const totalStock = footwear.reduce((sum, item) => sum + item.quantity, 0);
    const lowStock = footwear.filter(item => item.quantity <= 5);

    setStats({
      totalStock,
      totalBrands: brands.length,
      lowStockItems: lowStock.length,
      todaySales,
      todayBills: todayBills.length,
    });

    setLowStockItems(lowStock);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Stock</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalStock}</p>
            </div>
            <Package className="w-12 h-12 text-blue-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Brands</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.totalBrands}</p>
            </div>
            <Tag className="w-12 h-12 text-green-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Low Stock</p>
              <p className="text-3xl font-bold text-red-600 mt-2">{stats.lowStockItems}</p>
            </div>
            <AlertTriangle className="w-12 h-12 text-red-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today Sales</p>
              <p className="text-2xl font-bold text-gray-900 mt-2">₹{stats.todaySales}</p>
            </div>
            <DollarSign className="w-12 h-12 text-emerald-500" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today Bills</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{stats.todayBills}</p>
            </div>
            <FileText className="w-12 h-12 text-orange-500" />
          </div>
        </div>
      </div>

      {lowStockItems.length > 0 && (
        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center">
              <AlertTriangle className="w-6 h-6 text-red-500 mr-2" />
              <h2 className="text-xl font-semibold text-gray-800">Low Stock Alerts</h2>
            </div>
          </div>
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Brand</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Color</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Quantity</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {lowStockItems.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm text-gray-900">{item.brandName}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.category}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.type}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.size}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">{item.color}</td>
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {item.section}-{item.rack}-{item.shelf}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full font-medium">
                          {item.quantity}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
